def calculate_value_edge(prob, odds):
    return prob - odds
