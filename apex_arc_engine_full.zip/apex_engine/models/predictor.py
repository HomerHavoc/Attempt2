def predict_home_runs(data):
    return data
