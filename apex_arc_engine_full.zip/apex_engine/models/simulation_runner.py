def run_simulations():
    return True
