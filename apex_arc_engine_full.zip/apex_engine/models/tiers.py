def assign_tiers(player_stats):
    return "Alpha"
