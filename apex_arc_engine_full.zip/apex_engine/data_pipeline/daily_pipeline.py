def run_pipeline():
    return True
