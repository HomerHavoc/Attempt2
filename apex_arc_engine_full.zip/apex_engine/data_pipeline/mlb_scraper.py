def scrape_mlb_data():
    return {}
