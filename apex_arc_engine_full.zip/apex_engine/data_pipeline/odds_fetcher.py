def fetch_odds():
    return {}
