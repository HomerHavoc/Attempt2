def update_lineups():
    return True
