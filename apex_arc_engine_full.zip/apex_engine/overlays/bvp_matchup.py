def get_bvp_stats(hitter, pitcher):
    return {}
