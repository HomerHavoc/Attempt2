def detect_surprise_breakouts():
    return []
