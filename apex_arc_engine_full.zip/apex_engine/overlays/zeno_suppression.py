def suppress_cold_zone(player):
    return False
