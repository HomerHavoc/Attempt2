def adjust_for_fatigue(player):
    return player
