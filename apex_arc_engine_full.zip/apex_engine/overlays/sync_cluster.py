def sync_momentum(player_list):
    return player_list
