def apply_quantum_entropy(player):
    return 0.02
