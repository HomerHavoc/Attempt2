def map_zone_damage(hitter):
    return []
