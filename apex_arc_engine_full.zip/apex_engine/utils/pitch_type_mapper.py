def map_pitch_to_vulnerability(pitch, hitter):
    return 0.1
