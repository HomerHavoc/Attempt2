def adjust_for_weather(weather_data):
    return 1.0
