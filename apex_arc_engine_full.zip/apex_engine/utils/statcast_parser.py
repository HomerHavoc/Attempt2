def parse_statcast_json(json_data):
    return []
