def load_lineups():
    return []
