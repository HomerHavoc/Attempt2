# Apex Arc Engine

Autonomous home run prediction engine using Statcast data, overlays, and betting intelligence.
