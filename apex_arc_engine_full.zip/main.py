from apex_engine.main_engine import run_daily_predictions

if __name__ == '__main__':
    run_daily_predictions()
