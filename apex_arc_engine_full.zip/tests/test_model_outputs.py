def test_predictions():
    assert True
