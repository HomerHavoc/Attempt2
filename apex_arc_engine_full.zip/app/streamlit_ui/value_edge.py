def visualize_value_edges(data):
    return data
