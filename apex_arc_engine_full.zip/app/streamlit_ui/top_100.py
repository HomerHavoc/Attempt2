def show_top_predictions():
    return []
