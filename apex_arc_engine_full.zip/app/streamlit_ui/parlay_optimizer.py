def optimize_parlay(picks):
    return picks
