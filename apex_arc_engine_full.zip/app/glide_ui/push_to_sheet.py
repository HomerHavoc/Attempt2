def push_predictions_to_sheet(data):
    return True
