def format_for_glide(data):
    return data
